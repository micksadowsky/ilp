package uk.ac.ed.inf.aqmaps;

public class Reading {
	String location;
	Double battery;
	String reading;
	
	public Reading(String location, Double battery, String reading) {
		this.location = location;
		this.battery = battery;
		this.reading = reading;
	}
	
}
