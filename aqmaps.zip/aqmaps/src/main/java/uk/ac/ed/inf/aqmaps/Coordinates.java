package uk.ac.ed.inf.aqmaps;

public class Coordinates {
	Coors coordinates;
	public static class Coors {
		Double lng;
		Double lat;
	}
}
